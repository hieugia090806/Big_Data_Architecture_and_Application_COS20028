//Import crucial libraries and tools. //
package stubs;

import java.util.Date;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.hadoop.io.Text;
import java.text.SimpleDateFormat;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.mapreduce.Mapper;

public class Assign1Mapper extends Mapper<LongWritable, Text, Text, IntWritable> {
	// Define the constant map output value (Writable Type).
	private final static IntWritable ONE = new IntWritable(1);
	private Text outputKey = new Text();
	
	// Requirement 1: Use Regular Expressions to validate and filter tokens. 
	// 1.1 Matches words that start with a letter.
	private static final Pattern ALPHABET_PATTERN = Pattern.compile("^[a-zA-Z]+");
	private SimpleDateFormat outputFormat;
	
	@Override
	protected void setup (Context context) throws IOException, InterruptedException {
		// Requirement 2: Format dates to Year-Month. 
		outputFormat = new SimpleDateFormat("yyyy-MM");
	}
	
	@Override
	protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
		// Convert input line to standard Java string and trim whitespaces.
		String line = value.toString().trim();
		if (line.isEmpty()) {
			return; // Skip process if line is blank
		}
		// Token the line individual words based on any whitespace delimiter. 
		String[] tokens = line.split("\\s+");
		
		for (String token : tokens) {
			// Requirement 3: Use Character.isDigit() to inspect the first character of the token
			if (token.length() > 0 && Character.isDigit(token.charAt(0))) {
				try {
					String yearMonth = outputFormat.format(new Date());
					outputKey.set("NUMERIC-RECORD-" + yearMonth);
					context.write(outputKey, ONE);
				} catch (Exception e) {
					// Ignores corrupted rows or unparseable text format data
				}
			} else {
				Matcher matcher = ALPHABET_PATTERN.matcher(token);
				if (matcher.find()) {
					String cleanword = matcher.group();
					outputKey.set("TEXT-KEY-" + cleanword);
					context.write(outputKey, ONE);
				}
			}
		}
	}
}
