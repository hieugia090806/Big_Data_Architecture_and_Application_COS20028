// Import crucial libraries and tools.
package stubs;

import java.io.IOException;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.mapreduce.Reducer;

public class Assign1Reducer extends Reducer<Text, IntWritable, Text, IntWritable> {
	private IntWritable finalResult = new IntWritable();
	
	@Override
	protected void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException {
		int totalCount = 0;
		
		for (IntWritable value : values) {
			totalCount += value.get();
		}
		
		finalResult.set(totalCount);
		context.write(key, finalResult);
	}
}
