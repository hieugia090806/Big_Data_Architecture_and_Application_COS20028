package stubs;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.mapreduce.Mapper;

public class Assign1Mapper extends Mapper<LongWritable, Text, Text, IntWritable> {
	private static final IntWritable ONE = new IntWritable(1);
	private final Text outputKey = new Text();
	
	@Override
	protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
		String line = value.toString().trim();
		if (line.isEmpty()) {
			return;
		}
		
		String[] parts = line.split("\\s+");
		if (parts.length >= 2) {
			String countValue = parts[parts.length - 1];
			boolean isNumeric = true;
			for (int i=0; i<countValue.length(); i++) {
				if (!Character.isDigit(countValue.charAt(i))) {
					isNumeric = false;
					break;
				}
			}
			
			if (isNumeric) {
				outputKey.set(countValue);
				context.write(outputKey, ONE);
			}
		}
	}
}