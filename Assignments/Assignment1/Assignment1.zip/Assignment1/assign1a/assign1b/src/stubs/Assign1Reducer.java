package stubs;

import java.io.IOException;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.mapreduce.Reducer;

public class Assign1Reducer extends Reducer<Text, IntWritable, Text, IntWritable> {
	private final IntWritable finalResult = new IntWritable();
	
	@Override
	protected void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException {
		int totalFrequency = 0;
		for (IntWritable value : values) {
			totalFrequency += value.get();
		}
		
		finalResult.set(totalFrequency);
		context.write(key, finalResult);
	}
	
}