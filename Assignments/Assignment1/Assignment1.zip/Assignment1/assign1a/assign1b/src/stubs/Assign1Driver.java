// Import crucial libraries and tools. //
package stubs;

import java.util.Date;
import java.text.SimpleDateFormat;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.util.ToolRunner;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class Assign1Driver extends Configured implements Tool{
	
	@Override
	public int run(String[] args) throws Exception {
		if (args.length != 2) {
			System.err.println("Usage: Assign1Driver <input path> <output path>");
			return -1;
		}
		
		Job job = Job.getInstance(getConf(), "COS20028 Assignment01 - Part01");
		job.setJarByClass(Assign1Driver.class);
		
		job.setMapperClass(Assign1Mapper.class);
		job.setReducerClass(Assign1Reducer.class);
		
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(IntWritable.class);
		
		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		
		return job.waitForCompletion(true) ? 0 : 1;
	}
	
	public static void main(String[] args) throws Exception {
		// Print Name and Student ID.
		System.out.println("Student Nme: Truong Ngoc Gia Hieu");
		System.out.println("Student ID: 105565520");
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		System.out.println("Program Executed at: " + formatter.format(new Date()));
		
		int exitStatus = ToolRunner.run(new Configuration(), new Assign1Driver(), args);
		System.exit(exitStatus);
	}
}
